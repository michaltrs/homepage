/*
 * Main.java
 *
 * Created on 29. prosinec 2005, 20:12
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package vhdltidy;

import java.util.Scanner;
import net.michaltrs.Syntax;

/**
 *
 * @author Misak
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Program pro kontrolu syntaxe VHDL a prevod do HTML");
        String fileName;
        
        
        if (args.length == 0) {
            System.out.println("Zadejte nazev VHDL zdojaku: ");
            //BufferedReader buf = new BufferedReader(new InputStreamReader());
            Scanner stdin = new Scanner(System.in);
            fileName = stdin.nextLine();
        } else {
            fileName = args[0];
        }
        
        Syntax s = new Syntax(fileName);
        
        
        /*
        String file = "ee_data_int.vhd";
        
         if (false) {   
            Lexan l = new Lexan(file);
            System.out.println("Test lexan");
            while ((l.symbol != Lexan.LexSymbol.symbEOF) && (l.symbol != Lexan.LexSymbol.err)) {
                l.CtiSymbol();
                System.out.println("symbol: " + l.symbol.toString() + " value: " + l.symbVal);
            }

        } else {
             System.out.println("Test syntax");
             Syntax s = new Syntax(file);
        }
         */
         
    }
    
    
}
