/*
 * DeclTab.java
 *
 * Created on 11. leden 2006, 12:47
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.michaltrs;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 *
 * @author Misak
 */
public class DeclTab {
    private Map git = new HashMap();
    private Map lit = new HashMap();
    
    /** Creates a new instance of DeclTab */
    public DeclTab() {
    }
    
    public String addIdent(String name, boolean local) {
        if (local) 
            return addLocalIdent(name);
        else 
            return addGlobalIdent(name);
    }
    
    private String addGlobalIdent(String name) {
        Random ro = new Random();
        
        String s = name+"_"+ro.nextInt(1000);
        git.put(name,s);
        return s;
    }
    
    private String addLocalIdent(String name) {
        Random ro = new Random();
        
        String s = name+"_"+ro.nextInt(1000);
        lit.put(name,s);
        return s;
    }
    
    public String getIdent(String name) {
        if (lit.containsKey(name))
            return (String)lit.get(name);
        else        
            return (String) git.get(name);
    }
    
    public void newLocal() {
        lit.clear();
    }
}
