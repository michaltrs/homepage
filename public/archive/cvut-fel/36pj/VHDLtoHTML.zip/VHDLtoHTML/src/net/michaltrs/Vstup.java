/*
 * Vstup.java
 *
 * Created on 29. prosinec 2005, 20:19
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package net.michaltrs;

import java.io.*;

/**
 *
 * @author Misak
 */
public class Vstup {
    BufferedReader br;

    public Vstup(String soubor) throws FileNotFoundException {
        br = new BufferedReader(new FileReader(soubor));
    }

    int ctiZnak() {
        try {
            return br.read();
        } catch (IOException ex) {
            return -1;
        }
    }

    String ctiRadku() {
        try {
            String s = br.readLine();
            return s;
        } catch (IOException ex) {
        }
        return null;
    }

}
