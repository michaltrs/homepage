#!/bin/bash
# Michal Trs
#
# 36NAN - strom telecom data
# Data z ustredny rozdeli po tydnech 
# Vstup: Data z ustredny .txt
# Vystup: Data z ustredny rozdelana po tydnech 
# Nazev vystupnich souboru: cislo_tydne.raw
#

rm -f *.raw;

for file in $@; do 
  echo $file;    
  awk -F, 'BEGIN {kWEEK = 60*60*24*7}
                 {print $0 >> int($5/kWEEK) ".raw"}' "$file"
done;

