#!/bin/bash
# Michal Trs
#
# 36NAN - strom telecom data
#

  awk '        {callperday[$1]++}
               {callperhour[$1, $2]++}
               {all[$1, $2, $3, $4]++}
       $5 == 1 {uspech[$1, $2]++}
        END   {for (i in all) { 
                 split(i, sep, "\034")
                 sta = (uspech[sep[1], sep[2]] / callperhour[sep[1], sep[2]]) * 100; # procentualni uspesnost
                 #cnt = (callperhour[sep[1], sep[2]] / callperday[sep[1]]) * 100;
                 printf "%d %d %d %d ", sep[1], sep[2], sep[3], sep[4]; 
                 #printf "%.1f %.0f\n", cnt, sta;
                 printf "%.0f\n", sta;
              }}' $1
