package net.michaltrs;

import java.io.Serializable;

public class TableItem implements Serializable {
    public String brana;
    public int vzdalenost;

    public TableItem() {
    }

    public TableItem(String gw, int vzd) {
        brana = gw;
        vzdalenost = vzd;
    }

    public String toString() {
      return brana + "\t" + vzdalenost;
    }
}

