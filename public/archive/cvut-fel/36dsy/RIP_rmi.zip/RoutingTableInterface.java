package net.michaltrs;

import java.rmi.*;
import javax.swing.*;
import java.util.*;


public interface RoutingTableInterface extends Remote {
    boolean isEmpty() throws RemoteException;
    Map getTable(String name) throws RemoteException;
}
