

#ifndef __SUP_FUNC_H__584616491__
#define __SUP_FUNC_H__584616491__

#include <sys\timeb.h>

#define SIZE 128   // packet size in B
#define TIMEOUT 5  // timeout in s
#define WIN_SIZE 4 // flow window size

#define INFO 1     // show info == 1

typedef unsigned char MSG[SIZE];

typedef struct {
   MSG msg;
   int used;
   unsigned char trueLen;
   struct timeb time;
} WIN_ITEM;
        
typedef WIN_ITEM WINDOW[WIN_SIZE];  

      


int isLess(unsigned char uk, unsigned char ul); // ret 1 if  k <= l

int isTimeout(struct timeb msgTime);

void setAktTime(struct timeb *msgTime);

#endif
