// POMOCNE FUNKCE PRO udp.c a udps.c

#include <sys\timeb.h>
#include "sup_func.h"


int isLess(unsigned char uk, unsigned char ul) { // ret 1 if  k <= l
   int k, l;
   
   k = (int) uk;
   l = (int) ul;

   if ( (k < 50) && (l > 200) ) return 0;   
   if (k - l <= -252) return 0;
   if (k - l >=  252) k -= 255;
   return k <= l;
} // isLess


int isTimeout(struct timeb msgTime) {
   struct timeb curTime;
   int t_diff;
   
   ftime(&curTime);    
   t_diff = (int) (1000 * (curTime.time - msgTime.time)
     + (curTime.millitm - msgTime.millitm));     
   return t_diff >= 1000 * TIMEOUT;                                       
} // itTimeout


void setAktTime(struct timeb *msgTime) {
   ftime(msgTime);       
} // struct timeb msgTime
