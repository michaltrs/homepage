package net.michaltrs;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 * Graficky objekt bod, pouziva se pri kresleni perem
 *
 * @author Michal Trs
 */
public class Dot extends Shape {
    private int x,y;
    private Color c;

    public Dot(int x, int y, Color c) {
        this.x = x;
        this.y = y;
        this.c = c;
    }

    /**
     * paint
     *
     * @param g Graphics2D
     * @todo Implement this net.michaltrs.Shape method
     */
    public void paint(Graphics2D g) {
        g.setColor(c);
        g.drawOval(x,y,2,2);
    }
}
