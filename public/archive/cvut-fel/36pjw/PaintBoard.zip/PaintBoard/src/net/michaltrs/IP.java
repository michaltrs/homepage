package net.michaltrs;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * <p>Title: Paint Board</p>
 *
 * <p>Description: painting network board using RMI</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author Michal Trs
 * @version 1.0
 */
public class IP {
    InetAddress address;

    public IP() {
        address = null;
        try {
            address = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

    public String getIP() {
        return address.getHostAddress();
    }

    public String getHN() {
        return address.getHostName();
    }
}

//System.out.println(new IP().getIP());
//System.out.println(new IP().getHN());
