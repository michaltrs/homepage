package net.michaltrs;

import java.awt.BorderLayout;
import java.awt.Frame;

import javax.swing.JDialog;
import javax.swing.JPanel;
import java.awt.*;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextPane;

/**
 * Dialogove okno pro zadavani textu na plochu
 */
public class DlgText extends JDialog {
    JPanel panel1 = new JPanel();
    JPanel jPanel1 = new JPanel();
    BorderLayout borderLayout2 = new BorderLayout();
    JLabel jLabel1 = new JLabel();
    JTextField jTextField1 = new JTextField();
    FlowLayout flowLayout1 = new FlowLayout();
    JPanel jPanel2 = new JPanel();
    FlowLayout flowLayout2 = new FlowLayout();
    JButton BtnOK = new JButton();

    private String text;

    public DlgText(Frame owner, String title, boolean modal) {
        super(owner, title, modal);
        try {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
            pack();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public DlgText() {
        this(new Frame(), "DlgText", false);
    }

    public String getText() {
        return text;
    }

    private void jbInit() throws Exception {
        panel1.setLayout(flowLayout1);
        this.getContentPane().setLayout(borderLayout2);
        jLabel1.setText("Type text here:");
        jTextField1.addActionListener(new DlgText_jTextField1_actionAdapter(this));
        jTextField1.setPreferredSize(new Dimension(70, 21));
        jPanel2.setLayout(flowLayout2);
        BtnOK.setText("OK");
        BtnOK.addActionListener(new DlgText_BtnOK_actionAdapter(this));
        jPanel1.add(jLabel1);
        jPanel1.add(jTextField1);
        jPanel2.add(BtnOK);
        panel1.add(jPanel1, null);
        this.getContentPane().add(panel1, java.awt.BorderLayout.NORTH);

        this.getContentPane().add(jPanel2, java.awt.BorderLayout.CENTER);
    }

    public void jTextField1_actionPerformed(ActionEvent e) {

    }

    public void BtnOK_actionPerformed(ActionEvent e) {
        text = jTextField1.getText();
        this.dispose();
    }
}


class DlgText_BtnOK_actionAdapter implements ActionListener {
    private DlgText adaptee;
    DlgText_BtnOK_actionAdapter(DlgText adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.BtnOK_actionPerformed(e);
    }
}


class DlgText_jTextField1_actionAdapter implements ActionListener {
    private DlgText adaptee;
    DlgText_jTextField1_actionAdapter(DlgText adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jTextField1_actionPerformed(e);
    }
}
