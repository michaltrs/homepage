package net.michaltrs;

import java.awt.Graphics2D;
import java.awt.Color;

/**
 * Graficky objekt elipsa
 *
 * @author Michal Trs
 */
public class Oval extends Shape {
    Color color;
    int x, y, w, h;

    public Oval() {
    }

    public Oval(int x1, int y1, int x2, int y2, Color c) {
        x = x1;
        y = y1;
        color = c;

        w = x2 - x1;
        h = y2 - y1;

        if (w < 0) {
            w *= -1;
            x = x2;
        }

        if (h < 0) {
            h *= -1;
            y = y2;
        }
    }

    /**
     * paint
     *
     * @param g Graphics2D
     * @todo Implement this net.michaltrs.Shape method
     */
    public void paint(Graphics2D g) {
        g.setColor(color);
        g.drawOval(x,y,w,h);
    }
}
