package net.michaltrs;

import java.awt.Graphics2D;
import java.awt.Color;

/**
 * Graficky objekt text
 *
 * @author Michal Trs
 */
public class Text extends Shape {
    private int x, y;
    private Color color;
    private String t;

    public Text() {
    }

    public Text(int x, int y, String text, Color c) {
        this.x = x;
        this.y = y;
        t = text;
        color = c;
    }

    /**
     * paint
     *
     * @param g Graphics2D
     * @todo Implement this net.michaltrs.Shape method
     */
    public void paint(Graphics2D g) {
        g.setColor(color);
        g.drawString(t,x,y);
    }
}
