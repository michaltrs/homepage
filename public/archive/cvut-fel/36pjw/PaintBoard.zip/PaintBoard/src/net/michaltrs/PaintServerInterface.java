package net.michaltrs;


import java.awt.Color;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Date;

/**
 * funkce poskytovane servrem PaintServer
 *
 * @version 1.0
 */
public interface PaintServerInterface extends Remote {
    void paintLine(int x1, int y1, int x2, int y2, Color c) throws RemoteException;
    void paintRect(int x1, int y1, int x2, int y2, Color c) throws RemoteException;
    void paintOval(int x1, int y1, int x2, int y2, Color c) throws RemoteException;
    void paintText(int x, int y, String text, Color c) throws RemoteException;
    Shape[] getBoard() throws RemoteException;
    boolean isUpDate(Date d) throws RemoteException;
    void clearBoard() throws RemoteException;
}
