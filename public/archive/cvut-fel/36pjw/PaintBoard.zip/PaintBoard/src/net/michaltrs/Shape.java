package net.michaltrs;

import java.io.Serializable;
import java.awt.Graphics2D;

/**
 * Abstraktni trida, deklaruje pouze metodu pro vykresleni.
 * Z teto tridy jsou dedeny vsechny dalsi graficke objekty
 *
 * @author Michal Trs
 */
public abstract class Shape implements Serializable {
        public abstract void paint(Graphics2D g);
}

