/*
  Name: pfunc.h
  Copyright: 
  Author: Michal Trs
  Date: May 2005
  Description: print function
*/

#include "data.h"


#ifndef __PFUNC_H__61655616__
#define __PFUNC_H__61655616__


/* definitions elementary functions */

void printBYTE(unsigned char value);

void printASCII(unsigned char *from, unsigned long int adr, unsigned long int len);

void printSHORT(unsigned int value);

void printLONG(unsigned long int value);

void printSLONG(long int value);


/* definitions complex functions */

int ErrMsg(int errCode); /* print error message and return error code */

int printIFDname(unsigned int tagID, IFDtype typ);

int printIFDvalue(unsigned int tagID, unsigned int df, unsigned long int coc, unsigned long int index, int decode);

void showHelp(void);

#endif
