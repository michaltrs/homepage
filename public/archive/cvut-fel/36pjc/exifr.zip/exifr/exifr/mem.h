/*
  Name: mem.h
  Copyright: 
  Author: Michal Trs
  Date: May 2005
  Description: memory
*/


#ifndef __MEM_H__584616491__
#define __MEM_H__584616491__


extern int LE ;          /* 1 = little endian,     0 = big endian */
extern unsigned char *mem; 
extern unsigned long int memIndex;
extern unsigned long int memSize;


/* test end of memory  1=OK, 0=out of memory*/
int test(unsigned long int offset);

/* get Byte from memory */
unsigned char getBYTE(unsigned long int adr);

/* get usigned integer (2B) from memory */
unsigned int getSHORT(unsigned long int adr);

/* get unsigned integer (4B) from memory */
unsigned long int getLONG(unsigned long int adr);

/* get rational */
double getRATIONAL(unsigned long int adr);

/* get integer 4B from memory */
long int getSLONG(unsigned long int adr);

/* get signed rational from memory */
double getSRATIONAL(unsigned long int adr);

#endif
