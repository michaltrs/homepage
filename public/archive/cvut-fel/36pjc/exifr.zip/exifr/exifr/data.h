/*
  Name: data.h
  Copyright: 
  Author: Michal Trs
  Date: May 2005
  Description: definitions datas
*/



#ifndef __DATA_H__456465456__
#define __DATA_H__456465456__



/* data declaration */

typedef struct {
  int key;
  char *TagName;       
} tItem;

typedef struct {
  int key;
  tItem values[10];         
} tSpecItem;

typedef enum {tIFD0,tIFD1,tEXIF,tGPS,tMAKER} IFDtype;


extern tItem ErrArr[];

extern tItem IFD0[]; 
                              
extern tItem IFDex[];  

extern int dataPcom[];

extern tSpecItem spec[];
           
extern char *help;


#endif
