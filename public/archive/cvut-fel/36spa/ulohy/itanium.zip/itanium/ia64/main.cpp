#include <stdio.h>

extern "C" {
  void student();
}  

int main() {
  student();
}
