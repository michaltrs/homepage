/*
  types.h
 */
/* 
   BlueMP3 firmware (c) 2004 by Till Harbaum, harbaum@beecon.de
*/


#ifndef TYPES_H
#define TYPES_H

#ifndef NULL
#define NULL ((void*)0)
#endif

#define PACKED __attribute__ ((packed))

/* various useful types */
typedef unsigned long int  u32_t;
typedef signed long int    s32_t;
typedef unsigned short int u16_t;
typedef signed short int   s16_t;
typedef unsigned char      u08_t;
typedef signed char        s08_t;
typedef unsigned char      bool_t;

#define FALSE 0
#define TRUE  1

#endif // TYPES_H
