/*
  hci_info.h

  informational command handling
*/
/* 
   BlueMP3 firmware (c) 2004 by Till Harbaum, harbaum@beecon.de
*/



#ifndef HCI_INFO_H
#define HCI_INFO_H

void hci_info_init(void);

typedef struct {
  u08_t status;     // ok = 0, else error
  u16_t acl_len;    // buffer lengths and numbers
  u08_t sco_len;
  u16_t acl_num;
  u16_t sco_num;
} PACKED hci_buffers_t;

#endif // HCI_INFO_H
