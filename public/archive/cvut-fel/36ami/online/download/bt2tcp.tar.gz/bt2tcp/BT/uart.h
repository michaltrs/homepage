/*
  uart.h
*/

#ifndef UART_H
#define UART_H

#include "types.h"

void uart_putc(u08_t chr);
u08_t uart_input_avail(void);
u08_t uart_getc(void);

#endif // UART_H
