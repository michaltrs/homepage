/* types.cpp 
 * helpfull function for packet processing
 *
 * Michal Trs, Jirka Sejtko
 * CVUT FEL, K336
 */

#include <pcap.h>
#include "types.h"

/* TCP flag function */
bool cwr(u_char flags) { return (flags & 0x80) != 0; };
bool ece(u_char flags) { return (flags & 0x40) != 0; };
bool urg(u_char flags) { return (flags & 0x20) != 0; };
bool ack(u_char flags) { return (flags & 0x10) != 0; };
bool psh(u_char flags) { return (flags & 0x08) != 0; };
bool rst(u_char flags) { return (flags & 0x04) != 0; };
bool syn(u_char flags) { return (flags & 0x02) != 0; };
bool fin(u_char flags) { return (flags & 0x01) != 0; };