#include <stdio.h>

main() {
  printf("\007");
}