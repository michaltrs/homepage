/************************************************************************ 
 *  buffer.h
 *  buffer pro odesilani a prijimani zprav
 *
 *  36PAR - Othello 
 *  Michal Augustyn (augusm1@fel.cvut.cz), Michal Trs (trsm1@fel.cvut.cz)
*************************************************************************/

#ifndef __BUFFER_H__452676721__
#define __BUFFER_H__452676721__

   typedef struct {
      char *buffer;
	  int velikost;
	  int pozice;
      int kapacita;        
   } Buffer;


  void bufferInit(Buffer* buffer, int kapacita);
  void bufferDeinit(Buffer* buffer);

#endif
