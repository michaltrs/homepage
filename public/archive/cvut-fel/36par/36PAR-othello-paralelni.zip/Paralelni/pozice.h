/************************************************************************ 
 *  pozice.h
 *  pozice na sachovnici
 *
 *  36PAR - Othello 
 *  Michal Augustyn (augusm1@fel.cvut.cz), Michal Trs (trsm1@fel.cvut.cz)
*************************************************************************/

#ifndef __POZICE_H__452676721__
#define __POZICE_H__452676721__

#include "buffer.h"

   typedef struct {
      int x;
      int y;        
   } Pozice;


/* zapakuje pozici */
void pozicePack(Pozice* zdroj, Buffer* cil);

/* rozpakuje pozici */
void poziceUnpack(Pozice* cil, Buffer* zdroj);


#endif
