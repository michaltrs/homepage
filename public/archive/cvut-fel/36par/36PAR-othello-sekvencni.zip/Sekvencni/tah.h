/************************************************************************ 
 *  tah.h
 *  tah pro sekvencni reseni ...
 *
 *  36PAR - Othello 
 *  Michal Augustyn (augusm1@fel.cvut.cz), Michal Trs (trsm1@fel.cvut.cz)
*************************************************************************/

#ifndef __TAH_H__452676721__
#define __TAH_H__452676721__

#include "pozice.h"

   typedef struct {
      Pozice pozice;
      int cisloTahu;
      int zahrany;
      int pocetObarveni;
      Pozice* obarveni;
   } Tah;

   /* provede inicializaci tahu */
   void tahInit(Tah* tah, int x, int y, int cisloTahu);
   
   /* uvolni alokovane zdroje */
   void tahDeinit(Tah* tah);
   
   /* prida obarveni do tahu */
   void tahPridejObarveni(Tah* tah, int x, int y);
   
   
#endif
