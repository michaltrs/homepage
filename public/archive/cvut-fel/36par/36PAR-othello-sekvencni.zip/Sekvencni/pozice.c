/************************************************************************ 
 *  pozice.c
 *  tah pro sekvencni reseni, implementace ...
 *
 *  36PAR - Othello 
 *  Michal Augustyn (augusm1@fel.cvut.cz), Michal Trs (trsm1@fel.cvut.cz)
*************************************************************************/

#include "pozice.h"
