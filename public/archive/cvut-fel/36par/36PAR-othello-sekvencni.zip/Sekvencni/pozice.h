/************************************************************************ 
 *  pozice.h
 *  pozice pro sekvencni reseni ...
 *
 *  36PAR - Othello 
 *  Michal Augustyn (augusm1@fel.cvut.cz), Michal Trs (trsm1@fel.cvut.cz)
*************************************************************************/

#ifndef __POZICE_H__452676721__
#define __POZICE_H__452676721__

   typedef struct {
      int x;
      int y;        
   } Pozice;

#endif
