using System;
using System.Collections.Generic;
using System.Text;

namespace Batoh_experiment
{
    class BB : Batoh
    {
        private int actCost;
        private int actWeigt;
        private bool[] actX;

        private bool foundSolution = false;



        public BB(string input) : base(input)
        {
            actX = new bool[n];
            actCost = 0;
            actWeigt = M;
            algName = "B&B";
        }


        public override int Compute()
        {
            for (int i = 0; i < n; i++)
            {
                findSolution(i);
            }
            return cost;
        }



        private void findSolution(int index)
        {
            operCnt++;

            // vlozim vec na pozici index do batohu
            actX[index] = true;
            actWeigt -= v[index];
            actCost += c[index];

            // o�ez�v�n� shora (p�ekro�en� kapacity batohu)
            // vec se uz do batohu nevejde, nema vyznam pridavat dal + vec vyndam
            if (actWeigt < 0)
            {
                actX[index] = false;
                actWeigt += v[index];
                actCost -= c[index];
                return;
            }

            // o�ez�v�n� zdola (st�vaj�c� �e�en� nem��e b�t lep�� ne� nejlep�� dosud nalezen�)
            // nejvysi mozna cena teto konfigurece
            if (foundSolution)
            {
                int maxCost = 0;

                for (int i = 0; i < n; i++)
                {
                    if (i < index)
                    {
                        if (actX[i]) maxCost += c[i];
                    }
                    else
                    {
                        maxCost += c[i];
                    }                     
                }

                if (maxCost < cost)
                {
                    actX[index] = false;
                    actWeigt += v[index];
                    actCost -= c[index];
                    return;
                }
            }

            // rekurzivne hledam dalsi reseni
            for (int i = index + 1; i < n; i++)
                findSolution(i);

            // zkontroluju jestli jsem nasel nove nejlepsi reseni
            if (actCost >= cost)
            {
                cost = actCost;
                M = actWeigt;
                x = (bool[])actX.Clone();
                foundSolution = true;
            }

            // odeberu vec index z batohu
            actX[index] = false;
            actWeigt += v[index];
            actCost -= c[index];

        }               
    }
}
