#!/bin/bash
# parametr je jmeno souboru bez pripony


./KCPSM3.EXE $1.psm

rm ./*.DAT
rm ./*.MEM
rm ./*.FMT
rm ./*.HEX
mv rom_form.coe rom_form.x
rm ./*.COE
mv rom_form.x rom_form.coe
rm ./*.TXT
rm ./*.DEC
rm ./*.M
rm ./*.V


mv $1.VHD $1.tmp
head -n 49 $1.tmp > $1.vhd

./conv.sh $1.LOG 0 0 >> $1.vhd
./conv.sh $1.LOG 1 0 >> $1.vhd
./conv.sh $1.LOG 2 0 >> $1.vhd
./conv.sh $1.LOG 3 0 >> $1.vhd
./conv.sh $1.LOG 4 0 >> $1.vhd

echo "" >> $1.vhd
echo "signal lastmem : std_logic_vector(3 downto 0);" >> $1.vhd
echo "" >> $1.vhd
echo "begin" >> $1.vhd
echo "" >> $1.vhd
./conv.sh $1.LOG 0 1 >> $1.vhd
./conv.sh $1.LOG 1 1 >> $1.vhd
./conv.sh $1.LOG 2 1 >> $1.vhd
./conv.sh $1.LOG 3 1 >> $1.vhd
./conv.sh $1.LOG 4 1 >> $1.vhd

echo "

  instruction(17 downto 16) <= lastmem(1 downto 0); 

end low_level_definition;
--
------------------------------------------------------------------------------------
--
-- END OF FILE app_rom.vhd
--
------------------------------------------------------------------------------------ 
"  >> $1.vhd
